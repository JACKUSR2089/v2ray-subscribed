- 1.推荐使用最新版本的bbr+fq或者bbr+cake
```
# 这里是别人评测的地址
https://roov.org/2020/03/bbr-bbrplus-bbr2/
```
- 2.测试订阅链接用的是最新的bbr+fq
