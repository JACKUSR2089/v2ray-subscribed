# 安装wget、curl
- Centos
```
yum update && yum install -y wget curl
```

- Debian
```
apt update && apt install wget curl -y
```

- Ubuntu
```
apt-get update && apt-get install wget -y
```