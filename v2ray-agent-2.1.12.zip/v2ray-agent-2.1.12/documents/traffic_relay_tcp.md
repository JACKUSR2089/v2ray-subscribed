- [1.准备工作](#1准备工作)
- [2.购买流量转发服务](#2购买流量转发服务)
- [3.配置流量转发服务](#3配置流量转发服务)
- [4.修改客户端](#4修改客户端)
- [5.游戏代理](#5游戏代理)

# 1.准备工作
- 1.需要一台VPS。
- 2.这里建议使用shadowsocks。
- 3.购买流量转发服务[点击购买](https://idc.wiki)

# 2.购买流量转发服务
- 1.注册-->[idc.wiki](https://idc.wiki)
- 2.注册完成后，[点击购买](https://idc.wiki/exnetwork.php)，无aff。

# 3.配置流量转发服务
## 1.配置idc.wiki流量转发
- 1.服务-->我的产品和服务-->管理产品-->添加普通转发&添加IPLC转发，如果需要游戏代理，这里则必须选择第三个，同时转发TCP+UDP。
- 2.配置转发规则【示例：173.82.112.30:37210】

# 4.修改客户端
- 客户端部分修改地址和端口为wikihost分配的端口+ip

# 5.游戏代理
- 建议使用[Netch](https://github.com/NetchX/Netch/releases)
- Netch设置不是很复杂，这里不过多描述，[官网入门教程](https://github.com/NetchX/Netch/blob/master/docs/Quickstart.zh-CN.md)。
