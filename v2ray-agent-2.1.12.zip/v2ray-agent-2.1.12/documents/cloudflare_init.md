* * *
# 目录
- [1.注册Cloudfalre](#1注册cloudfalre)
- [2.添加域名](#2添加域名)
- [3.修改SSL/TLS mode](#3修改ssltls-mode)
- [4.添加A记录](#2添加A记录)
* * *

# 1.注册Cloudflare
- 1.打开[Cloudflare](https://dash.cloudflare.com/sign-up)，并注册

<img src="https://raw.githubusercontent.com/mack-a/v2ray-agent/master/fodder/cloudflare/cloudflare_signup_01.png" width=600>

# 2.添加域名
- 1.添加域名

<img src="https://raw.githubusercontent.com/mack-a/v2ray-agent/master/fodder/cloudflare/cloudflare_add_website.png" width=600>

- 2.添加后修改域名提供商的 NameServer

<img src="https://raw.githubusercontent.com/mack-a/v2ray-agent/master/fodder/cloudflare/cloudfalre_add_website_02.png" width=600>

- 3.修改NameServer

>这里以godaddy为例

<img src="https://raw.githubusercontent.com/mack-a/v2ray-agent/master/fodder/cloudflare/cloudflare_website_godaddy_ns.png" width=600>

# 3.修改SSL/TLS mode
- SSL/TLS->Full

<img src="https://raw.githubusercontent.com/mack-a/v2ray-agent/master/fodder/cloudflare/cloudflare_SSL_mode.png" width=600>

# 4.添加A记录
- 云朵必须为灰色
- 到这里Cloudflare的添加域名、A解析就完成了。

<img src="https://raw.githubusercontent.com/mack-a/v2ray-agent/master/fodder/cloudflare/cloudflare_dns_a.png" width=600>

